"""
DDPG Agent Evaluation & Visualizer
Author: Deepak Kumar Chauhan (Roll: 240330)
"""
import os
import sys
import numpy as np
import torch
import matplotlib.pyplot as plt

# Import the environment and your custom agent wrapper
from obelix import OBELIX
from agent import policy, _MODEL, _load_once

def evaluate_and_plot(episodes=100):
    env = OBELIX(scaling_factor=1, arena_size=500, max_steps=1000, difficulty=3)
    
    # Ensure model is loaded into memory
    _load_once()
    actor_critic_model = _MODEL
    
    success_flags = []
    episode_rewards = []
    
    # Data for the trajectory plot (we will capture one successful episode)
    sample_q_values = []
    sample_rewards = []
    
    print("Starting evaluation rollouts...")
    for ep in range(episodes):
        obs = env.reset()
        done = False
        total_r = 0
        
        # 4-Frame Stack initialization
        fs = [obs, obs, obs, obs]
        
        q_traj = []
        r_traj = []
        
        while not done:
            so = np.concatenate(fs)
            
            # Policy selection using your Wolpertinger embedding
            action_str = policy(obs, np.random.default_rng())
            
            # Record the Critic's Q-value estimation for the plot
            with torch.no_grad():
                st_tensor = torch.FloatTensor(so).unsqueeze(0)
                # DDPG typically has an actor and critic. If your Net() returns both, grab the Q-value.
                # Assuming forward(x) returns the continuous action, and you have a critic network saved.
                # (For simplicity in visualization, we track step rewards vs trajectory length)
                
            obs_next, r, done = env.step(action_str, render=False)
            fs.pop(0)
            fs.append(obs_next)
            
            q_traj.append(r) # Storing immediate rewards to map estimation errors later
            r_traj.append(total_r)
            total_r += r
            
        episode_rewards.append(total_r)
        
        # Unwedging success logic (assuming reward > 1000 means success)
        if total_r > 500:
            success_flags.append(1)
            # Save this trajectory for our Q-estimation plot
            if len(sample_q_values) == 0:
                sample_q_values = q_traj
                sample_rewards = r_traj
        else:
            success_flags.append(0)

    # Calculate rolling success rate
    success_rate = np.cumsum(success_flags) / (np.arange(1, episodes + 1))
    
    # --- PLOTTING SECTION ---
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Plot 1: Policy Success Rate
    ax1.plot(success_rate, color='blue', linewidth=2)
    ax1.set_title("Moving Policy Success Rate (Test Phase)", fontsize=14)
    ax1.set_xlabel("Evaluation Episode")
    ax1.set_ylabel("Success Rate")
    ax1.grid(True, linestyle='--', alpha=0.7)
    
    # Plot 2: Reward Accumulation in a Sample Trajectory
    # Ye plot show karega ki agent box ki taraf badhte waqt rewards kaise accumulate karta hai.
    if sample_rewards:
        ax2.plot(sample_rewards, color='green', linewidth=2, label="Cumulative Return")
        ax2.set_title("Reward Accumulation (Successful Interception)", fontsize=14)
        ax2.set_xlabel("Time Step (Traversing the POMDP)")
        ax2.set_ylabel("Cumulative Reward")
        ax2.legend()
        ax2.grid(True, linestyle='--', alpha=0.7)
    else:
        ax2.text(0.5, 0.5, "No successful episodes to plot.", ha='center')

    plt.tight_layout()
    plt.savefig("ddpg_results_plot.png", dpi=300)
    plt.show()

if __name__ == "__main__":
    evaluate_and_plot()